/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_circling_pseudo_sort.c                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: msessa <mikysett@gmail.com>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/05/25 17:27:43 by msessa            #+#    #+#             */
/*   Updated: 2021/06/30 18:15:51 by msessa           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_push_swap.h"

static t_ps	*ft_circling_do_pseudo_sort(t_list ***checks,
				t_stack *s, int pos, int first_pos);

void	ft_circling_pseudo_sort(t_stack *s)
{
	int			i;
	t_ps		*best;
	t_ps		*new;
	t_list		***checks;

	i = 0;
	best = 0;
	s->lis_lvl++;
	checks = ft_init_checks(s->size);
	while (i < s->size)
	{
		new = ft_circling_do_pseudo_sort(checks, s, i, i);
		ft_save_check(checks[i], new);
		ft_take_best(&best, &new);
		i++;
	}
	ft_set_is_sorted(s, best);
	ft_free_checks(checks, s->size);
}

static t_ps	*ft_circling_do_pseudo_sort(t_list ***checks,
				t_stack *s, int pos, int f_pos)
{
	t_ps_rec	rec;
	t_nb		*nb;
	int			i;

	ft_init_ps_rec(&rec, s, pos);
	i = (pos + 1) % s->size;
	while (i != f_pos)
	{
		nb = &s->stack[i];
		if (!nb->lis_lvl && nb->nb < rec.pos_nb)
		{
			if (rec.best && rec.best->score > ft_chunk_size(s->size, i, f_pos))
				break ;
			rec.new = ft_best_checked(checks[i], s->size, i, f_pos);
			if (!rec.new)
			{
				rec.new = ft_circling_do_pseudo_sort(checks, s, i, f_pos);
				ft_save_check(checks[i], rec.new);
			}
			ft_take_best(&rec.best, &rec.new);
		}
		i = (i + 1) % s->size;
	}
	return (ft_set_result(rec.best, s->size, pos, f_pos));
}
