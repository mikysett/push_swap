/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_extract_sorted.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: msessa <mikysett@gmail.com>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/05/14 16:59:05 by msessa            #+#    #+#             */
/*   Updated: 2021/06/30 13:25:02 by msessa           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_push_swap.h"

static void	ft_extract_first_lvl(t_data *data, int lis_lvl);
static void	ft_extract_lis_lvl_from_stack(t_data *data,
				t_s_name in_name, int lis_lvl);

void	ft_extract_sorted(t_data *data)
{
	int	lis_lvl;

	data->s_a.size_unsorted = 0;
	data->s_b.size_unsorted = 0;
	lis_lvl = 1;
	ft_extract_first_lvl(data, lis_lvl);
	ft_rotate_sorted(data, stack_a);
	lis_lvl += 2;
	while (data->s_a.size_unsorted || data->s_b.size_unsorted)
	{
		if (data->s_a.size_unsorted)
			ft_extract_lis_lvl_from_stack(data, stack_a, lis_lvl);
		else
			ft_extract_lis_lvl_from_stack(data, stack_b, lis_lvl);
		lis_lvl += 2;
	}
}

static void	ft_extract_first_lvl(t_data *data, int lis_lvl)
{
	t_nb	*stack_a;

	stack_a = data->s_a.stack;
	while (!ft_only_one_lvl(&data->s_a))
	{
		ft_expand_lvl_by_swap(data, &data->s_a, lis_lvl);
		if (stack_a[data->s_a.top].lis_lvl == lis_lvl)
			ft_rotate_a(data);
		else if (stack_a[data->s_a.top].lis_lvl == lis_lvl + 1)
		{
			ft_push_b(data);
			ft_rotate_b(data);
		}
		else
		{
			ft_push_b(data);
			data->s_b.size_unsorted++;
		}
	}
}

static void	ft_extract_lis_lvl_from_stack(t_data *data,
	t_s_name from_name, int lis_lvl)
{
	t_merge_info	info;

	info.in_name = ft_opposite_s(from_name);
	ft_init_stacks_name(data, &info);
	while (info.s_from->size_unsorted > 0)
	{
		if (info.s_from->stack[info.s_from->top].lis_lvl == lis_lvl)
			ft_rotate_stack(data, from_name);
		else if (info.s_from->stack[info.s_from->top].lis_lvl == lis_lvl + 1)
		{
			ft_push_stack(data, ft_opposite_s(from_name));
			ft_rotate_stack(data, ft_opposite_s(from_name));
		}
		else if (lis_lvl % 4 == 1
			&& ft_expand_lvl_by_swap(data, info.s_from, lis_lvl))
			continue ;
		else
		{
			ft_push_stack(data, ft_opposite_s(from_name));
			info.s_in->size_unsorted++;
		}
		info.s_from->size_unsorted--;
	}
}
