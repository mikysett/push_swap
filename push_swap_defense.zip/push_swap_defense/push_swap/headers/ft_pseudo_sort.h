/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_pseudo_sort.h                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: msessa <mikysett@gmail.com>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/05/14 15:54:02 by msessa            #+#    #+#             */
/*   Updated: 2021/06/30 18:33:34 by msessa           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_PSEUDO_SORT_H
# define FT_PSEUDO_SORT_H

void	ft_pseudo_sort(t_stack *s);
t_ps	*ft_do_pseudo_sort(t_list ***checks, t_stack *s, int pos, int f_pos);
t_ps	*ft_set_result(t_ps *best, int size, int pos, int first_pos);
void	ft_update_stack_and_checks(t_list ***checks, t_ps *best, t_stack *s);

#endif