/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_reduce_checked.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: msessa <mikysett@gmail.com>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/06/04 16:22:53 by msessa            #+#    #+#             */
/*   Updated: 2021/06/30 12:45:38 by msessa           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_push_swap.h"

static int	ft_get_biggest_chunk_size(t_list *curr_check);
static void	ft_delete_sgl_check(t_list **checks, t_list *curr,
				t_list *prev, t_list *next);

void	ft_reduce_checked(t_list **checks)
{
	t_list	*curr;
	t_list	*next;
	t_list	*prev;
	t_ps	*curr_ps;
	int		biggest_size;

	biggest_size = ft_get_biggest_chunk_size(*checks);
	prev = 0;
	curr = *checks;
	while (curr)
	{
		next = curr->next;
		curr_ps = (t_ps *)curr->content;
		if (curr_ps->protection_lvl <= 0 && curr_ps->chunk_size < biggest_size)
			ft_delete_sgl_check(checks, curr, prev, next);
		else
			prev = curr;
		curr = next;
	}
}

static int	ft_get_biggest_chunk_size(t_list *curr_check)
{
	t_ps	*curr_check_ps;
	int		biggest_chunk_size;

	biggest_chunk_size = 0;
	while (curr_check)
	{
		curr_check_ps = (t_ps *)curr_check->content;
		if (curr_check_ps->chunk_size > biggest_chunk_size)
			biggest_chunk_size = curr_check_ps->chunk_size;
		curr_check = curr_check->next;
	}
	return (biggest_chunk_size);
}

static void	ft_delete_sgl_check(t_list **checks, t_list *curr,
				t_list *prev, t_list *next)
{
	if (!prev)
		*checks = next;
	else
		prev->next = next;
	ft_lstdelone(curr, ft_free_sgl_check);
}
