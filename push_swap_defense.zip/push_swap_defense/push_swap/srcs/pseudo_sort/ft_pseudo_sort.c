/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_pseudo_sort.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: msessa <mikysett@gmail.com>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/05/25 17:27:43 by msessa            #+#    #+#             */
/*   Updated: 2021/06/30 18:33:51 by msessa           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_push_swap.h"

static t_ps	*ft_init_result(int size, int pos, int first_pos);

void	ft_pseudo_sort(t_stack *s)
{
	t_list		***checks;

	checks = ft_init_checks(s->size);
	while (!ft_all_sorted_set(s))
	{
		s->lis_lvl++;
		ft_single_lvl_pseudo_sort(checks, s);
	}
	ft_free_checks(checks, s->size);
}

t_ps	*ft_do_pseudo_sort(t_list ***checks, t_stack *s, int pos, int f_pos)
{
	t_ps_rec	rec;
	t_nb		*nb;
	int			i;

	ft_init_ps_rec(&rec, s, pos);
	i = pos;
	while (++i < s->size)
	{
		nb = &s->stack[i];
		if (!nb->lis_lvl && nb->nb < rec.pos_nb)
		{
			if (rec.best && rec.best->score >= ft_chunk_size(s->size, i, f_pos))
				break ;
			ft_reduce_checked(checks[i]);
			rec.new = ft_best_checked(checks[i], s->size, i, f_pos);
			if (!rec.new)
			{
				rec.new = ft_do_pseudo_sort(checks, s, i, f_pos);
				ft_save_check(checks[i], rec.new);
			}
			ft_take_best(&rec.best, &rec.new);
		}
	}
	return (ft_set_result(rec.best, s->size, pos, f_pos));
}

t_ps	*ft_set_result(t_ps *best, int size, int pos, int first_pos)
{
	t_ps	*res;

	res = ft_init_result(size, pos, first_pos);
	if (!best)
		return (res);
	pos = (pos + 1) % size;
	while (pos != best->start_pos)
		pos = (pos + 1) % size;
	while (pos != first_pos)
	{
		if (best->hash[pos] != 0)
			res->hash[pos] = 1;
		pos = (pos + 1) % size;
	}
	res->score += best->score;
	best->protection_lvl--;
	return (res);
}

static t_ps	*ft_init_result(int size, int pos, int first_pos)
{
	t_ps	*res;

	res = ft_calloc(1, sizeof(t_ps));
	if (res)
		res->hash = ft_calloc(size, sizeof(char));
	if (!res || !res->hash)
		ft_exit_failure();
	res->hash[pos] = 1;
	res->start_pos = pos;
	res->score = 1;
	res->size = size;
	res->chunk_size = ft_chunk_size(size, pos, first_pos);
	return (res);
}

void	ft_update_stack_and_checks(t_list ***checks, t_ps *best, t_stack *s)
{
	if (best)
	{
		ft_set_is_sorted(s, best);
		ft_remove_invalid_checks(checks, s);
	}
}
