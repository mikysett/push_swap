/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_init_merge.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: msessa <mikysett@gmail.com>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/05/14 16:59:05 by msessa            #+#    #+#             */
/*   Updated: 2021/06/30 18:07:58 by msessa           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_push_swap.h"

static void	ft_prepare_reversed_merge(t_merge_info *m);

void	ft_init_merge(t_data *data, t_merge_info *m)
{
	ft_chose_best_top_lvl(data);
	m->reversed_merge = false;
	if (ft_top_lvl_reversed(&data->s_a, data->s_a.top)
		&& ft_top_lvl_reversed(&data->s_b, data->s_b.top))
		m->reversed_merge = true;
	else
		ft_prepare_reversed_stacks(data);
	if (m->reversed_merge)
		ft_prepare_reversed_merge(m);
	else if (ft_bottom_lvl_reversed(&data->s_a, 0))
		m->in_name = stack_b;
	else if (ft_bottom_lvl_reversed(&data->s_b, 0))
		m->in_name = stack_a;
	else
		m->in_name = ft_choose_best_stack_to_merge(data);
	ft_init_stacks_name(data, m);
	if (m->s_from->size > 0)
		m->lvl_from = m->s_from->stack[m->s_from->top].lis_lvl;
	if (m->s_in->size > 0)
		m->lvl_in = m->s_in->stack[m->s_in->top].lis_lvl;
}

static void	ft_prepare_reversed_merge(t_merge_info *m)
{
	if (m->reverse_into_b)
		m->in_name = stack_a;
	else
		m->in_name = stack_b;
	m->reverse_into_b = !m->reverse_into_b;
}
