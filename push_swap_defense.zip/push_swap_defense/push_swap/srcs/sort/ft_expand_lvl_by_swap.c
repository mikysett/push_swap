/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_expand_lvl_by_swap.c                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: msessa <mikysett@gmail.com>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/05/14 16:59:05 by msessa            #+#    #+#             */
/*   Updated: 2021/06/30 13:26:34 by msessa           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_push_swap.h"

static bool	ft_expand_one_before_top(t_data *data, t_stack *s,
				int lis_lvl);
static bool	ft_expand_the_top(t_data *data, t_stack *s, int lis_lvl);
static bool	ft_expand_one_before_top_next_lvl(t_data *data, t_stack *s,
				int lis_lvl);
static bool	ft_expand_the_top_next_lvl(t_data *data, t_stack *s, int lis_lvl);

bool	ft_expand_lvl_by_swap(t_data *data, t_stack *s, int lis_lvl)
{
	bool	lvl_expanded;

	lvl_expanded = false;
	if (s->top <= 0)
		return (false);
	else if (s->stack[s->top].lis_lvl == lis_lvl)
		lvl_expanded = ft_expand_one_before_top(data, s, lis_lvl);
	else if (s->stack[s->top - 1].lis_lvl == lis_lvl)
		lvl_expanded = ft_expand_the_top(data, s, lis_lvl);
	else if (s->stack[s->top].lis_lvl == lis_lvl + 1)
		lvl_expanded = ft_expand_one_before_top_next_lvl(data, s, lis_lvl);
	else if (s->stack[s->top - 1].lis_lvl == lis_lvl + 1)
		lvl_expanded = ft_expand_the_top_next_lvl(data, s, lis_lvl);
	return (lvl_expanded);
}

static bool	ft_expand_one_before_top(t_data *data, t_stack *s,
				int lis_lvl)
{
	if (s->stack[s->top - 1].lis_lvl != lis_lvl
		&& ft_can_be_in_middle(s->stack[s->top - 1].nb,
			&s->stack[s->top], ft_next_in_lvl(s, s->top, lis_lvl)))
	{
		s->stack[s->top - 1].lis_lvl = lis_lvl;
		ft_swap_a(data);
		return (true);
	}
	return (false);
}

static bool	ft_expand_the_top(t_data *data, t_stack *s, int lis_lvl)
{
	if (ft_can_be_in_middle(s->stack[s->top].nb,
			&s->stack[s->top - 1], ft_next_in_lvl(s, s->top - 1, lis_lvl)))
	{
		s->stack[s->top].lis_lvl = lis_lvl;
		ft_swap_a(data);
		return (true);
	}
	return (false);
}

static bool	ft_expand_one_before_top_next_lvl(t_data *data, t_stack *s,
				int lis_lvl)
{
	if (s->stack[s->top - 1].lis_lvl != lis_lvl + 1
		&& ft_can_be_in_middle(s->stack[s->top - 1].nb,
			&s->stack[s->top], ft_next_in_lvl(s, s->top, lis_lvl + 1)))
	{
		s->stack[s->top].lis_lvl = lis_lvl + 1;
		ft_swap_a(data);
		return (true);
	}
	return (false);
}

static bool	ft_expand_the_top_next_lvl(t_data *data, t_stack *s, int lis_lvl)
{
	if (ft_can_be_in_middle(s->stack[s->top].nb,
			&s->stack[s->top - 1],
			ft_next_in_lvl(s, s->top - 1, lis_lvl + 1)))
	{
		s->stack[s->top].lis_lvl = lis_lvl + 1;
		ft_swap_a(data);
		return (true);
	}
	return (false);
}
